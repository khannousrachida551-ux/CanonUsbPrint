package com.canonusbprint

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var usbManager: UsbManager
    private lateinit var status: TextView
    private lateinit var deviceList: LinearLayout
    private val ACTION_USB_PERMISSION = "com.canonusbprint.USB_PERMISSION"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usbManager = getSystemService(USB_SERVICE) as UsbManager
        status = findViewById(R.id.status)
        deviceList = findViewById(R.id.deviceList)

        findViewById<Button>(R.id.refreshButton).setOnClickListener { scanUsb() }
        findViewById<Button>(R.id.fileButton).setOnClickListener { chooseFile() }

        scanUsb()
    }

    private fun scanUsb() {
        deviceList.removeAllViews()
        val devices = usbManager.deviceList.values.toList()

        if (devices.isEmpty()) {
            status.text = "لا توجد أجهزة USB متصلة"
            return
        }

        status.text = "تم العثور على ${devices.size} جهاز USB"

        devices.forEach { device ->
            val row = TextView(this).apply {
                text = "الجهاز: ${device.deviceName}\nVID: %04X   PID: %04X".format(
                    device.vendorId, device.productId
                )
                textSize = 16f
                setPadding(24, 24, 24, 24)
            }
            deviceList.addView(row)

            if (device.vendorId == 0x04A9) {
                status.text = "تم اكتشاف طابعة Canon عبر USB"
                requestPermission(device)
            }
        }
    }

    private fun requestPermission(device: UsbDevice) {
        if (usbManager.hasPermission(device)) {
            status.text = "تم السماح بالوصول إلى Canon: ${device.deviceName}"
        } else {
            val intent = Intent(ACTION_USB_PERMISSION)
            val pending = PendingIntent.getBroadcast(
                this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE
            )
            usbManager.requestPermission(device, pending)
        }
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/*"))
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 100)
    }

    override fun onResume() {
        super.onResume()
        scanUsb()
    }
}
