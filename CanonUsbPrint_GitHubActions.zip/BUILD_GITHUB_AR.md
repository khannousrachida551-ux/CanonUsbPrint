# بناء APK عبر GitHub Actions

1. أنشئ مستودع GitHub جديد.
2. ارفع **محتويات هذا المجلد** إلى المستودع (وليس ملف ZIP نفسه داخل المستودع).
3. تأكد أن الملف `.github/workflows/build.yml` موجود.
4. من GitHub افتح تبويب **Actions**.
5. شغّل **Build Android APK** بواسطة **Run workflow**.
6. بعد نجاح البناء افتح نتيجة التشغيل ثم قسم **Artifacts**.
7. نزّل `CanonUsbPrint-debug.zip` وفك ضغطه لتحصل على `app-debug.apk`.
8. ثبّت APK على هاتف Android.

ملاحظة: هذا الإصدار يجهز الواجهة واكتشاف Canon عبر USB. بروتوكول الطباعة الفعلي يحتاج اختبارًا على الطابعة وإضافة طبقة Driver مناسبة.
